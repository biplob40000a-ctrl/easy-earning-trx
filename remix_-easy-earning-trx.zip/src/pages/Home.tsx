import { useAuth } from '../contexts/AuthContext';
import { store, VIP_LEVELS } from '../lib/store';
import { formatTRX } from '../lib/utils';
import { Megaphone, ArrowUpRight, ArrowDownRight, Wallet, Activity, ChevronRight, ShoppingBag, Lock, Zap, Gift, Trophy, Users, DollarSign } from 'lucide-react';
import { motion } from 'motion/react';
import { Link, useNavigate } from 'react-router-dom';
import { useEffect, useState, useRef } from 'react';
import { Transaction } from '../types';
import heroBg from '../assets/images/trx_heroes_background_1781765288717.jpg';

function HistoryModal({ onClose }: { onClose: () => void }) {
  const { user } = useAuth();
  const transactions = store.getState().transactions.filter(t => t.userId === user?.id).sort((a,b) => b.timestamp - a.timestamp);
  
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="w-full max-w-md bg-[var(--color-bg-card)] rounded-3xl border border-[var(--color-border-card)] p-6 shadow-2xl">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-xl font-bold">History</h3>
          <button onClick={onClose} className="p-2 bg-[var(--color-bg-base)] rounded-full text-text-muted hover:text-white">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
          </button>
        </div>
        <div className="space-y-4 max-h-[60vh] overflow-y-auto">
          {transactions.length === 0 ? (
            <div className="text-center py-10 text-text-muted">No history found</div>
          ) : (
            transactions.map(tx => (
              <div key={tx.id} className="bg-[var(--color-bg-base)] border border-[var(--color-border-card)] p-4 rounded-xl flex items-center justify-between">
                <div>
                  <div className="font-bold text-sm capitalize text-brand-gold">{tx.type}</div>
                  <div className="text-xs text-text-muted mt-1">{new Date(tx.timestamp).toLocaleString()}</div>
                </div>
                <div className={`font-bold ${tx.type === 'withdraw' ? 'text-blue-500' : 'text-green-500'}`}>
                  {tx.type === 'withdraw' ? '-' : '+'}{formatTRX(tx.amount)}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}

function NewsOffersSection({ state }: { state: any }) {
  const newsItems = [
    ...(state.billboardEnabled && state.billboardText ? [{ title: "System Update", text: state.billboardText }] : []),
    ...state.notices?.filter((n: any) => n.isActive).map((n: any) => ({ title: "Announcement", text: n.text })) || []
  ];

  if (newsItems.length === 0) return null;

  const Marquee = 'marquee' as any;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-3"
    >
      <div className="rounded-3xl overflow-hidden shadow-[0_0_30px_rgba(0,240,255,0.15)] border border-[#00FFFF]/20 relative flex flex-col h-[220px] transition-all hover:shadow-[0_0_40px_rgba(0,240,255,0.25)] group">
         {/* Animated Background Image Layer */}
         <motion.div 
            className="absolute inset-0 z-0 origin-center"
            animate={{ 
              scale: [1, 1.05, 1],
            }}
            transition={{
              duration: 15,
              repeat: Infinity,
              ease: "easeInOut"
            }}
            style={{ 
              backgroundImage: `url(${heroBg})`, 
              backgroundSize: 'cover', 
              backgroundPosition: 'center' 
            }}
         />

         {/* Magic Ambient Orbs / Glow */}
         <motion.div 
           className="absolute top-[20%] left-[30%] w-16 h-16 bg-[#00FFFF] rounded-full blur-2xl z-0 mix-blend-screen"
           animate={{ 
             scale: [1, 2, 1], 
             opacity: [0.1, 0.4, 0.1],
             x: [0, 20, 0],
             y: [0, -20, 0]
           }}
           transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
         />
         <motion.div 
           className="absolute top-[50%] right-[30%] w-24 h-24 bg-[#FF007A] rounded-full blur-3xl z-0 mix-blend-screen"
           animate={{ 
             scale: [1, 1.5, 1], 
             opacity: [0.1, 0.3, 0.1],
             x: [0, -30, 0],
             y: [0, 30, 0]
           }}
           transition={{ duration: 6, repeat: Infinity, ease: "easeInOut", delay: 1 }}
         />

         {/* Spinning TRX Logo (3D-like rotateY) */}
         <div className="absolute right-[-20px] top-0 bottom-0 flex items-center justify-center z-[5] opacity-20 md:opacity-30 pointer-events-none overflow-hidden">
            <motion.img 
              src="/trx-logo.svg" 
              alt="TRX Spinning"
              className="w-48 h-48 md:w-64 md:h-64 drop-shadow-[0_0_15px_rgba(0,240,255,0.8)]"
              animate={{ rotateY: [0, 360] }}
              transition={{ duration: 6, repeat: Infinity, ease: "linear" }}
              style={{ transformStyle: "preserve-3d" }}
            />
         </div>

         <div className="absolute inset-0 bg-black/40 bg-gradient-to-t from-black/90 via-black/30 to-black/50 z-0" />
         
         <div className="relative z-10 flex-1 min-w-0 flex flex-col p-5 justify-start h-full pointer-events-auto">
             <div className="flex items-center gap-2 text-sm text-[#00FFFF] font-bold tracking-wide uppercase drop-shadow mb-4">
               <Megaphone size={16} className="text-[#00FFFF] animate-pulse" />
               Live Updates
             </div>
             
             <div className="flex-1 overflow-hidden relative">
                <Marquee 
                  direction="up" 
                  scrollamount="2" 
                  className="h-full w-full"
                >
                  <div className="flex flex-col gap-6 pb-4">
                    {newsItems.map((item, i) => (
                      <div key={i} className="flex flex-col">
                        {item.title && <span className="text-[#00FFFF] font-bold text-[16px] md:text-[18px] drop-shadow mb-1">{item.title}:</span>}
                        <span className="text-white text-[15px] md:text-[17px] font-medium leading-relaxed whitespace-pre-wrap drop-shadow-md">{item.text}</span>
                      </div>
                    ))}
                  </div>
                </Marquee>
             </div>
         </div>
      </div>
    </motion.div>
  );
}

export default function Home() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const state = store.getState();
  const userVip = state.vipLevels?.find(v => v.level === user?.vipLevel) || state.vipLevels?.[0] || VIP_LEVELS[0];
  const [liveTrades, setLiveTrades] = useState<{id: string, type: 'buy'|'sell', price: string, amount: string, time: string}[]>([]);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);

  useEffect(() => {
    // Connect to Binance WebSocket for real TRX/USDT live trades
    const ws = new WebSocket('wss://stream.binance.com:9443/ws/trxusdt@trade');
    let tradeBuffer: any[] = [];
    
    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      const newTrade = {
        id: data.t.toString() + Math.random().toString(),
        type: data.m ? 'sell' : 'buy' as 'buy'|'sell',
        price: parseFloat(data.p).toFixed(4),
        amount: parseFloat(data.q).toFixed(1),
        time: new Date(data.T).toLocaleTimeString([], { hour12: false })
      };
      
      tradeBuffer = [newTrade, ...tradeBuffer].slice(0, 10);
      setLiveTrades([...tradeBuffer]);
    };

    // Fallback UI data until WS connects
    let currentPrice = 0.3326;
    const generateFallback = () => {
      const type = Math.random() > 0.5 ? 'buy' : 'sell';
      const priceChange = (Math.random() - (type === 'buy' ? 0.3 : 0.7)) * 0.0005;
      currentPrice = currentPrice + priceChange;
      
      return {
        id: `fallback-${Date.now()}-${Math.random()}`,
        type: type as 'buy'|'sell',
        price: currentPrice.toFixed(4),
        amount: (Math.random() * 5000 + 100).toFixed(1),
        time: new Date().toLocaleTimeString([], { hour12: false })
      };
    };
    
    setLiveTrades(Array.from({ length: 6 }).map(generateFallback).reverse());

    return () => {
      ws.close();
    };
  }, []);

  return (
    <div className="space-y-6 pb-6">
      <NewsOffersSection state={state} />

      <motion.div 
         initial={{ scale: 0.95, opacity: 0 }} 
         animate={{ scale: 1, opacity: 1 }}
         className="relative rounded-3xl p-6 overflow-hidden bg-gradient-to-br from-[#FF0013] to-[#80000A] shadow-[0_15px_35px_-10px_rgba(255,0,19,0.4)] backdrop-blur-md"
      >
         <div className="absolute top-0 right-0 p-4 opacity-20">
           <svg width="120" height="120" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round"><polygon points="12 2 2 12 12 22 22 12 12 2"/></svg>
         </div>
         <div className="relative z-10">
           <div className="text-white/80 text-sm font-medium mb-1">Total Balance</div>
           <div className="text-4xl font-bold text-white mb-6 drop-shadow-md">
             {formatTRX(user?.balance || 0)}
           </div>
           
           <div className="flex gap-4">
              <button onClick={() => navigate('/finance/deposit')} className="flex-1 bg-white/20 hover:bg-white/30 backdrop-blur-md text-white py-3 rounded-2xl font-bold transition-all flex items-center justify-center gap-2 shadow-inner border border-white/10">
                <ArrowUpRight size={20} /> Deposit
              </button>
              <button onClick={() => navigate('/finance/withdraw')} className="flex-1 bg-black/20 hover:bg-black/30 backdrop-blur-md text-white py-3 rounded-2xl font-bold transition-all flex items-center justify-center gap-2 shadow-inner border border-black/10">
                <ArrowDownRight size={20} /> Withdraw
              </button>
           </div>
         </div>
      </motion.div>

      <div className="grid grid-cols-5 gap-2">
        <QuickAction icon={<Wallet />} label="Recharge" onClick={() => navigate('/finance/deposit')} color="text-brand-primary" bg="bg-brand-primary/10" />
        <QuickAction icon={<ArrowDownRight />} label="Withdraw" onClick={() => navigate('/finance/withdraw')} color="text-blue-400" bg="bg-blue-400/10" />
        <QuickAction icon={<Lock />} label="Stake" onClick={() => navigate('/stake')} color="text-green-500" bg="bg-green-500/10" />
        <QuickAction icon={<ShoppingBag />} label="Shop" onClick={() => navigate('/shop')} color="text-brand-gold" bg="bg-brand-gold/10" />
        <QuickAction icon={<Activity />} label="History" onClick={() => setIsHistoryOpen(true)} color="text-purple-400" bg="bg-purple-400/10" />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="glass-panel p-4 rounded-3xl overflow-hidden">
          <div className="flex items-center gap-2 text-text-muted mb-2">
            <Wallet size={18} className="text-brand-gold shrink-0" />
            <span className="text-sm whitespace-nowrap">Today Earnings</span>
          </div>
          <div className="text-xl font-bold text-white truncate" title={formatTRX(0)}>{formatTRX(0)}</div>
        </div>
        <div className="glass-panel p-4 rounded-3xl overflow-hidden">
          <div className="flex items-center gap-2 text-text-muted mb-2">
            <Activity size={18} className="text-green-500 shrink-0" />
            <span className="text-sm whitespace-nowrap">Total Earnings</span>
          </div>
          <div className="text-xl font-bold text-white truncate" title={formatTRX(user?.totalEarnings || 0)}>{formatTRX(user?.totalEarnings || 0)}</div>
        </div>
      </div>

      <Link to="/vip" className="block glass-panel p-5 rounded-3xl relative overflow-hidden group">
        <div className="absolute inset-0 bg-gradient-to-r from-brand-gold/5 pointer-events-none group-hover:from-brand-gold/10 transition-colors" />
        <div className="flex items-center justify-between relative z-10">
          <div>
            <div className="text-brand-gold font-bold text-lg">{userVip.name}</div>
            <div className="text-sm text-text-muted mt-1">Daily Income: <span className="text-white">{formatTRX(userVip.dailyIncome)}</span></div>
          </div>
          <div className="w-10 h-10 bg-[var(--color-bg-base)] rounded-full flex items-center justify-center border border-[var(--color-border-card)]">
            <ChevronRight size={20} className="text-text-muted group-hover:text-brand-gold transition-colors" />
          </div>
        </div>
      </Link>

      {/* Official Partners / Supported Platforms */}
      <div className="py-2">
        <p className="text-center font-bold text-text-muted text-[10px] uppercase tracking-widest mb-4 flex items-center gap-2 justify-center">
          <span className="h-[1px] w-8 bg-gradient-to-r from-transparent to-[var(--color-border-card)]"></span>
          Supported Platforms
          <span className="h-[1px] w-8 bg-gradient-to-l from-transparent to-[var(--color-border-card)]"></span>
        </p>
        <div className="flex justify-center gap-6 items-center">
          <div className="flex items-center gap-1.5 opacity-60 grayscale hover:grayscale-0 hover:opacity-100 transition-all cursor-default">
             <div className="w-4 h-4 bg-[#FCD535] flex items-center justify-center transform rotate-45">
               <div className="w-1.5 h-1.5 bg-[#111]"></div>
             </div>
             <span className="font-bold text-white tracking-widest text-sm">BINANCE</span>
          </div>

          <div className="flex items-center gap-1 opacity-60 grayscale hover:grayscale-0 hover:opacity-100 transition-all cursor-default">
             <div className="font-black text-white tracking-tighter text-xl italic">
                BYB<span className="text-yellow-500">I</span>T
             </div>
          </div>

          <div className="flex items-center gap-1 opacity-60 grayscale hover:grayscale-0 hover:opacity-100 transition-all cursor-default">
             <div className="w-4 h-4 bg-[#FF060A] transform rotate-45 rounded-[2px]" style={{ clipPath: 'polygon(50% 0%, 0% 100%, 100% 100%)', transform: 'none', background: 'transparent', borderBottom: '16px solid #FF060A', borderLeft: '8px solid transparent', borderRight: '8px solid transparent' }}></div>
             <span className="font-bold text-white tracking-wider text-sm">TRON</span>
          </div>
        </div>
      </div>

      <div>
        <div className="flex justify-between items-center mb-5">
          <h3 className="text-xl font-bold flex items-center gap-2 drop-shadow">
            <Activity size={22} className="text-[#00FFFF]" /> Live Global Trading
          </h3>
          <span className="text-xs font-medium text-white px-3 py-1.5 bg-[#00FFFF]/10 border border-[#00FFFF]/20 rounded-full shadow-[0_0_10px_rgba(0,240,255,0.1)]">TRX / USDT</span>
        </div>
        
        <div className="bg-black/40 backdrop-blur-xl border border-white/5 rounded-3xl overflow-hidden shadow-2xl relative">
         <div className="absolute inset-0 bg-gradient-to-b from-[#00FFFF]/5 to-transparent pointer-events-none" />
         <div className="grid grid-cols-3 text-sm font-medium text-text-muted p-4 border-b border-white/10 bg-white/5 relative z-10">
            <div>Price</div>
            <div className="text-right">Qty (TRX)</div>
            <div className="text-right">Time</div>
         </div>
         <div className="flex flex-col relative h-[320px] overflow-hidden">
            <div className="flex-1 w-full flex flex-col pt-1">
              {liveTrades.map((trade, index) => (
                <motion.div 
                  key={trade.id}
                  initial={{ opacity: 0, x: -10, height: 0 }}
                  animate={{ opacity: 1, x: 0, height: 'auto' }}
                  transition={{ duration: 0.3 }}
                  className={`grid grid-cols-3 text-[15px] p-4 items-center font-mono relative z-10 transition-colors hover:bg-white/5 ${index % 2 === 0 ? 'bg-transparent' : 'bg-black/20'}`}
                >
                  <div className={`font-bold flex items-center gap-1.5 ${trade.type === 'buy' ? 'text-green-400' : 'text-rose-500'}`}>
                    {trade.type === 'buy' ? <ArrowUpRight size={16} /> : <ArrowDownRight size={16} />}
                    {trade.price}
                  </div>
                  <div className="text-right text-white/90 font-medium">
                    {trade.amount}
                  </div>
                  <div className="text-right text-text-muted text-[13px]">
                    {trade.time}
                  </div>
                </motion.div>
              ))}
            </div>
            {/* Fade out at bottom */}
            <div className="absolute bottom-0 left-0 w-full h-16 bg-gradient-to-t from-black via-black/80 to-transparent pointer-events-none z-20" />
         </div>
        </div>
      </div>
      
      {isHistoryOpen && <HistoryModal onClose={() => setIsHistoryOpen(false)} />}
    </div>
  );
}

function QuickAction({ icon, label, onClick, color, bg }: any) {
  return (
    <button onClick={onClick} className="flex flex-col items-center gap-2 group w-full">
      <div className={`w-[60px] h-[60px] rounded-2xl ${bg} ${color} flex items-center justify-center group-hover:scale-105 transition-transform border border-[var(--color-border-card)]/50`}>
        {icon}
      </div>
      <span className="text-[11px] font-medium text-text-muted group-hover:text-white transition-colors">{label}</span>
    </button>
  );
}
